﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class KeyBindManager
{
    private string dataPath;
    private List<KeyBind> keyBinds;
    public KeyBindManager(string KeyBindMapPath)
    {
        dataPath = KeyBindMapPath;
        keyBinds = new List<KeyBind>();
        string[] fileLines = File.ReadAllLines(dataPath);
        for(int i = 0; i < fileLines.Length; i++)
        {
            string[] splitLine = fileLines[i].Split(':');
            KeyCode keyCodeToString = (KeyCode)System.Enum.Parse(typeof(KeyCode), splitLine[1]);
            keyBinds.Add(new KeyBind(splitLine[0], keyCodeToString));
        }
    }

    public KeyCode getBinding(string identifier)
    {
        int i = 0;
        bool found = false;
        while(i < keyBinds.Count && !found)
        {
            if (keyBinds[i].getName() == identifier)
            {
                found = true;
            }
            else
            {
                i += 1;
            }
        }
        return keyBinds[i].getCode();
    }

    public void addBinding(string identifier, KeyCode keyCode)
    {
        keyBinds.Add(new KeyBind(identifier, keyCode));
        rewriteFile();
    }

    public void removeBinding(string identifier)
    {
        KeyBind kB = getBinding(identifier);
        keyBinds.Remove(kB);
        rewriteFile();
    }

    public void changeBinding(string identifier, KeyCode newKeyCode)
    {
        KeyBind kB = getBinding(identifier);
        kB.setCode(newKeyCode);
        rewriteFile();
    }

    public void rewriteFile()
    {
        string fileText = "";
        for(int i = 0; i < keyBinds.Count; i++)
        {
            KeyBind kB = keyBinds[i];
            string newLine = kB.getName() + ":" + kB.getCode() + "\n";
            fileText = fileText + newLine;
        }
        File.WriteAllText(dataPath, fileText);
    }
}
