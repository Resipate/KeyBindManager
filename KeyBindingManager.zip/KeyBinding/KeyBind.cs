﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyBind
{
    private string identifier;
    private KeyCode code; 
    public KeyBind(string iName, KeyCode iCode)
    {
        identifier = iName;
        code = iCode;
    }

    public string getName() { return identifier; }
    public KeyCode getCode() { return code; }
    public void setCode(KeyCode newCode) { code = newCode; }
}
